# ABBank SecPlatform — front-end redesign patch

Drop-in source implementing the direction in *Front-end Review*. Paths mirror the repo.

## Apply

1. `src/app/globals.css` — **replace**. ABBank brand tokens, the single risk ramp, warm neutrals, and the font fix.
2. `src/app/layout.tsx` — **one line**. The theme maps `--font-sans` to itself, so Geist never applies. See below.
3. Copy the rest in as new files. Nothing else is overwritten except the three data-display badges.

### layout.tsx

The `<body>` needs the loaded font variables in scope:

```diff
-<body className={`${geistSans.variable} ${geistMono.variable} antialiased`}>
+<body className={cn(geistSans.variable, geistMono.variable, "antialiased")}>
```

The real fix is in `globals.css`: `--font-sans: var(--font-geist-sans)` instead of `var(--font-sans)`.

## What each file is for

| File | Review finding it closes |
| --- | --- |
| `app/globals.css` | 2.1 four colour languages · §1 no identity |
| `lib/risk.ts` | 2.1 — one risk vocabulary, consumed by badges, rails, charts |
| `lib/use-filter-params.ts` | 2.4 — filter state in the URL, not `useState` |
| `components/filters/filter-bar.tsx` | filters on every page + dashboard date range |
| `components/data-display/severity-badge.tsx` | 2.1 |
| `components/data-display/status-badge.tsx` | 2.1 — status becomes neutral and typographic |
| `components/data-display/sla-indicator.tsx` | 2.3 — breach escalates |
| `components/data-display/provenance.tsx` | 2.7 — source, freshness, who changed it |
| `components/charts/chart-frame.tsx` | 2.6 — finding as title, table view, copy |
| `config/navigation.ts` | 2.8, 2.9 — nav by routine, declared as config |

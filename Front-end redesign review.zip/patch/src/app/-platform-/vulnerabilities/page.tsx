"use client";

import { useState } from "react";
import Link from "next/link";
import { useVulnerabilities } from "@/lib/queries/vulnerabilities";
import { useFilterParams } from "@/lib/use-filter-params";
import { FilterBar, type FilterDef, type SavedView } from "@/components/filters/filter-bar";
import { SeverityBadge } from "@/components/data-display/severity-badge";
import { StatusBadge } from "@/components/data-display/status-badge";
import { SlaIndicator } from "@/components/data-display/sla-indicator";
import { SEVERITIES, severity, type Severity } from "@/lib/risk";
import { cn } from "@/lib/utils";

/**
 * The queue an engineer lives in.
 *
 * Changed from the previous version: filters read from the URL so a queue is a
 * shareable link; saved views replace re-picking three selects; rows carry a
 * severity rail and selection with bulk verbs; the key is a real <Link> and
 * every other cell is plain selectable text, so the table copies into a
 * spreadsheet instead of navigating away mid-drag.
 */

const FILTERS: FilterDef[] = [
  { key: "severity", label: "severity", multi: true, options: SEVERITIES.map((s) => ({ value: s, label: severity[s].label })) },
  {
    key: "status", label: "status", multi: true,
    options: ["NEW", "TRIAGED", "ASSIGNED", "IN_PROGRESS", "PENDING_FIX", "READY_FOR_VERIFICATION", "CLOSED"]
      .map((v) => ({ value: v, label: v.replace(/_/g, " ").toLowerCase() })),
  },
  {
    key: "sla", label: "sla",
    options: [
      { value: "BREACHED", label: "Breached" },
      { value: "AT_RISK", label: "At risk" },
      { value: "ON_TRACK", label: "On track" },
    ],
  },
];

const SAVED_VIEWS: SavedView[] = [
  { id: "breached", label: "Breached", query: "sla=BREACHED&sort=due", tone: "critical" },
  { id: "mine", label: "My open", query: "assignee=me" },
  { id: "crit-unassigned", label: "Critical unassigned", query: "severity=CRITICAL&assignee=none" },
  { id: "verify", label: "Awaiting verification", query: "status=READY_FOR_VERIFICATION" },
  { id: "all", label: "All open", query: "" },
];

type Vuln = {
  id: string; key: string; title: string; severity: Severity; status: string;
  dueDate?: string | null; slaStatus?: string | null; createdAt: string;
  application?: { id: string; name: string } | null;
  fixOwner?: { name: string } | null;
};

export default function VulnerabilitiesPage() {
  const { params, setParam } = useFilterParams();
  const [selected, setSelected] = useState<Set<string>>(new Set());

  const { data, isLoading } = useVulnerabilities({
    search: params.search,
    severity: params.severity,
    status: params.status,
    sla: params.sla,
    assignee: params.assignee,
    sort: params.sort ?? "due",
    page: params.page ?? 1,
    pageSize: params.pageSize ?? 50,
  });

  const rows = (data?.data ?? []) as Vuln[];
  const total = data?.meta?.total ?? 0;

  function toggle(id: string) {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  }

  async function copySelection() {
    const picked = rows.filter((r) => selected.has(r.id));
    const tsv = picked
      .map((r) => [r.key, r.title, r.severity, r.application?.name ?? "", r.status].join(String.fromCharCode(9)))
      .join(String.fromCharCode(10));
    await navigator.clipboard.writeText(tsv);
  }

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <header className="border-b bg-card px-6 pt-4">
        <div className="flex items-end justify-between gap-5">
          <div className="flex items-baseline gap-3">
            <h1 className="text-2xl font-semibold tracking-tight">Vulnerabilities</h1>
            <span className="tnum font-mono text-[13px] text-muted-foreground">
              {total.toLocaleString()} open
            </span>
          </div>
          <div className="flex items-center gap-2 pb-1">
            <button type="button" className="rounded-md border bg-card px-3 py-1.5 text-xs">Columns</button>
            <button type="button" className="rounded-md border bg-card px-3 py-1.5 text-xs">Export CSV</button>
            <button type="button" className="rounded-md bg-primary px-3 py-1.5 text-xs font-medium text-primary-foreground">
              New finding
            </button>
          </div>
        </div>
        <nav className="mt-3 flex items-center gap-0.5">
          {SAVED_VIEWS.map((v) => (
            <Link
              key={v.id}
              href={v.query ? "?" + v.query : "/vulnerabilities"}
              className="border-b-2 border-transparent px-3 py-2 text-[13px] text-muted-foreground hover:text-foreground"
            >
              {v.label}
            </Link>
          ))}
        </nav>
      </header>

      <FilterBar filters={FILTERS} />

      {selected.size > 0 && (
        <div className="flex items-center gap-3.5 border-b bg-accent px-6 py-2 text-[12.5px] text-accent-foreground">
          <span className="font-semibold">{selected.size} selected</span>
          <span className="h-4 w-px bg-current opacity-25" />
          <button type="button">Assign to…</button>
          <button type="button">Set status</button>
          <button type="button">Request extension</button>
          <button type="button" onClick={copySelection}>Copy as TSV</button>
          <button type="button" onClick={() => setSelected(new Set())} className="ml-auto opacity-70">Clear</button>
        </div>
      )}

      <div className="flex-1 overflow-auto bg-card">
        <table className="w-full border-collapse text-[13px]">
          <thead className="sticky top-0 bg-muted/50">
            <tr className="border-b">
              <th className="w-9 py-2 pl-6" />
              {[
                { key: "key", label: "Key" },
                { key: "title", label: "Finding" },
                { key: "application", label: "Application" },
                { key: "status", label: "Status" },
                { key: "owner", label: "Owner" },
                { key: "due", label: "SLA" },
                { key: "age", label: "Age", align: "right" as const },
              ].map((c) => (
                <th
                  key={c.key}
                  className={cn(
                    "px-2.5 py-2 font-mono text-[10px] font-medium uppercase tracking-[0.09em]",
                    c.align === "right" ? "pr-6 text-right" : "text-left",
                    params.sort === c.key ? "text-foreground" : "text-muted-foreground",
                  )}
                >
                  <button type="button" onClick={() => setParam("sort", c.key)}>
                    {c.label}
                    {params.sort === c.key ? " ↑" : ""}
                  </button>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {isLoading && (
              <tr><td colSpan={8} className="px-6 py-10 text-center text-muted-foreground">Loading…</td></tr>
            )}
            {rows.map((v) => {
              const token = severity[v.severity];
              const breached = v.slaStatus === "BREACHED";
              return (
                <tr
                  key={v.id}
                  className={cn("border-b border-l-[3px]", token?.rail, breached && "bg-risk-critical-surface/45")}
                >
                  <td className="py-2 pl-6">
                    <input
                      type="checkbox"
                      checked={selected.has(v.id)}
                      onChange={() => toggle(v.id)}
                      aria-label={"Select " + v.key}
                      className="size-3.5 accent-[var(--brand)]"
                    />
                  </td>
                  <td className="px-2.5 py-2">
                    <Link href={"/vulnerabilities/" + v.id} className="font-mono text-[12.5px] text-primary hover:underline">
                      {v.key}
                    </Link>
                  </td>
                  <td className="px-2.5 py-2">
                    <span className="flex items-center gap-2.5">
                      <SeverityBadge value={v.severity} compact />
                      <span className="font-medium">{v.title}</span>
                    </span>
                  </td>
                  <td className="px-2.5 py-2 text-muted-foreground">{v.application?.name ?? "—"}</td>
                  <td className="px-2.5 py-2"><StatusBadge value={v.status} /></td>
                  <td className="px-2.5 py-2 text-muted-foreground">{v.fixOwner?.name ?? "Unassigned"}</td>
                  <td className="px-2.5 py-2"><SlaIndicator dueDate={v.dueDate} state={v.slaStatus} /></td>
                  <td className="tnum px-2.5 py-2 pr-6 text-right font-mono text-xs text-muted-foreground">
                    {Math.max(0, Math.round((Date.now() - new Date(v.createdAt).getTime()) / 86_400_000))}d
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

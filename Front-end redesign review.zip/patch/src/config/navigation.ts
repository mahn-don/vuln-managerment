import type { LucideIcon } from "lucide-react";
import {
  Inbox, GitCompareArrows, AlarmClock, LayoutGrid, ClipboardCheck, Bug,
  Activity, LineChart, Sparkles, ShieldCheck, Settings,
} from "lucide-react";

/**
 * Navigation as data.
 *
 * Two problems this closes. The sidebar listed entities in data-model order while
 * My Workspace — the screen an engineer opens first every morning — sat inside the
 * avatar dropdown. And the tree was a literal array inside sidebar.tsx, so every
 * CISO reshuffle was a pull request in a component.
 *
 * Groups are ordered by when in the day they are used, not by table name.
 * `badge` names a count the sidebar reads from the nav-counts endpoint;
 * `roles` gates a destination without branching inside the component.
 */

export type Role = "ENGINEER" | "MANAGER" | "EXECUTIVE" | "APP_OWNER" | "ADMIN";

export type NavItem = {
  label: string;
  href: string;
  icon: LucideIcon;
  /** Key into the counts payload; renders as a right-aligned figure */
  badge?: string;
  /** Render the count in the critical colour when non-zero */
  badgeTone?: "default" | "critical";
  roles?: Role[];
};

export type NavGroup = { id: string; label: string; items: NavItem[] };

export const navigation: NavGroup[] = [
  {
    id: "work",
    label: "My work",
    items: [
      { label: "My queue", href: "/workspace", icon: Inbox, badge: "myOpen" },
      { label: "Mapping review", href: "/mappings", icon: GitCompareArrows, badge: "unmapped" },
      { label: "Breached SLA", href: "/vulnerabilities?sla=BREACHED", icon: AlarmClock, badge: "breached", badgeTone: "critical" },
    ],
  },
  {
    id: "inventory",
    label: "Inventory",
    items: [
      { label: "Applications", href: "/applications", icon: LayoutGrid, badge: "applications" },
      { label: "Assessments", href: "/assessments", icon: ClipboardCheck, badge: "assessments" },
      { label: "Vulnerabilities", href: "/vulnerabilities", icon: Bug, badge: "openVulns" },
    ],
  },
  {
    id: "insight",
    label: "Insight",
    items: [
      { label: "Posture", href: "/dashboard/executive", icon: ShieldCheck },
      { label: "Operations", href: "/dashboard/operations", icon: Activity },
      { label: "Analytics", href: "/analytics", icon: LineChart },
      { label: "Ask the data", href: "/ai", icon: Sparkles },
    ],
  },
  {
    id: "admin",
    label: "",
    items: [{ label: "Administration", href: "/admin", icon: Settings, roles: ["ADMIN"] }],
  },
];

/** Where each role lands after login, instead of everyone getting Executive. */
export const landingByRole: Record<Role, string> = {
  ENGINEER: "/workspace",
  MANAGER: "/dashboard/operations",
  EXECUTIVE: "/dashboard/executive",
  APP_OWNER: "/applications",
  ADMIN: "/admin",
};

export function navigationFor(role: Role | undefined): NavGroup[] {
  return navigation
    .map((g) => ({ ...g, items: g.items.filter((i) => !i.roles || (role && i.roles.includes(role))) }))
    .filter((g) => g.items.length > 0);
}

import { cn } from "@/lib/utils";

/**
 * Was: eleven pastel hues competing with severity for the eye.
 * Now: typographic and neutral — a dot carries the state, colour is reserved
 * for risk and time. Workflow stage is a fact, not an alarm.
 */

const STATUS_LABELS: Record<string, string> = {
  NEW: "New",
  TRIAGED: "Triaged",
  ASSIGNED: "Assigned",
  IN_PROGRESS: "In progress",
  PENDING_FIX: "Pending fix",
  READY_FOR_VERIFICATION: "Ready to verify",
  VERIFIED: "Verified",
  CLOSED: "Closed",
  RISK_ACCEPTED: "Risk accepted",
  FALSE_POSITIVE: "False positive",
  REOPENED: "Reopened",
  DRAFT: "Draft",
  IN_REVIEW: "In review",
  APPROVED: "Approved",
};

/** Only states that mean "needs a human" get any colour at all. */
const STATUS_DOT: Record<string, string> = {
  NEW: "bg-risk-critical",
  REOPENED: "bg-risk-critical",
  TRIAGED: "bg-risk-high",
  PENDING_FIX: "bg-risk-medium",
  READY_FOR_VERIFICATION: "bg-brand",
  ASSIGNED: "bg-risk-low",
  IN_PROGRESS: "bg-risk-low",
  IN_REVIEW: "bg-risk-low",
};

export function StatusBadge({ value, className }: { value: string; className?: string }) {
  const label = STATUS_LABELS[value] ?? value.replace(/_/g, " ").toLowerCase();
  const dot = STATUS_DOT[value] ?? "bg-muted-foreground/45";
  return (
    <span className={cn("inline-flex items-center gap-1.5 text-[13px] text-muted-foreground", className)}>
      <span className={cn("size-1.5 shrink-0 rounded-full", dot)} aria-hidden />
      {label}
    </span>
  );
}

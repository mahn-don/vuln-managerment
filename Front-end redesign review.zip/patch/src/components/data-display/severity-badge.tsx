import { cn } from "@/lib/utils";
import { severity, type Severity } from "@/lib/risk";

/**
 * Was: solid bg-red-600 with white text, its own colour map.
 * Now: a tinted chip reading the shared ramp, so severity looks identical
 * in a table, a chart legend, a detail header and a suggestion card.
 */
export function SeverityBadge({
  value,
  compact = false,
  className,
}: {
  value: Severity | string;
  /** Four-character form for dense table cells */
  compact?: boolean;
  className?: string;
}) {
  const token = severity[value as Severity];
  if (!token) {
    return <span className={cn("text-xs text-muted-foreground", className)}>{value}</span>;
  }
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-sm px-1.5 py-0.5 font-mono text-[11px] font-semibold tracking-wide",
        token.surface,
        token.fg,
        className,
      )}
      title={token.label}
    >
      {compact ? token.short : token.label}
    </span>
  );
}

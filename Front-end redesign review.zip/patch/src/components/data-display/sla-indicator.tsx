import { cn } from "@/lib/utils";
import { daysRemaining, deriveSlaState, sla, type SlaState } from "@/lib/risk";

/**
 * Was: a 16px icon and the word "Breached" in the eighth column, as calm as
 * everything around it. Now the number is the message — days remaining, negative
 * when overdue — with a bar that fills as time runs out. Escalation is a property
 * of the component, not two hard-coded banners.
 */
export function SlaIndicator({
  dueDate,
  state,
  totalDays = 30,
  showBar = true,
  className,
}: {
  dueDate?: string | Date | null;
  state?: SlaState | string | null;
  /** SLA window for this severity, used to scale the bar */
  totalDays?: number;
  showBar?: boolean;
  className?: string;
}) {
  const resolved = (state as SlaState) ?? deriveSlaState(dueDate);
  const days = daysRemaining(dueDate);

  if (!resolved) {
    return <span className={cn("text-muted-foreground", className)}>&mdash;</span>;
  }

  const token = sla[resolved];
  const breached = resolved === "BREACHED";
  const pct = days === null ? 100 : breached ? 100 : Math.max(4, Math.min(100, ((totalDays - days) / totalDays) * 100));

  return (
    <span className={cn("inline-flex items-center gap-2", className)}>
      {showBar && (
        <span className="block h-[5px] w-11 shrink-0 bg-muted" aria-hidden>
          <span
            className="block h-[5px]"
            style={{ width: pct + "%", background: token.chart }}
          />
        </span>
      )}
      <span
        className={cn("tnum font-mono text-xs", token.fg, breached && "font-semibold")}
        title={token.label + (days === null ? "" : " — " + Math.abs(days) + " days " + (days < 0 ? "overdue" : "remaining"))}
      >
        {days === null ? token.label : (days < 0 ? "−" : "") + Math.abs(days) + "d"}
      </span>
    </span>
  );
}
